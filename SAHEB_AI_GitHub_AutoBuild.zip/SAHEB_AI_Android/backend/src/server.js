import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import OpenAI from 'openai';
const app=express(); app.use(cors()); app.use(express.json());
const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
app.get('/health',(req,res)=>res.json({ok:true,service:'SAHEB AI'}));
app.post('/ask',async(req,res)=>{try{const {question,location,landmark}=req.body; const prompt=`أنت صاحب، مرشد سياحي صوتي. أجب بالعربية بشكل طبيعي ومختصر. لا تخترع معلومات تاريخية. موقع المستخدم: ${JSON.stringify(location||{})}. المعلم الحالي: ${landmark||'غير معروف'}. سؤال المستخدم: ${question}`; const r=await client.responses.create({model:'gpt-5.6',input:prompt}); res.json({answer:r.output_text});}catch(e){res.status(500).json({error:'AI request failed'});}});
app.listen(process.env.PORT||8787,()=>console.log('SAHEB backend running'));
