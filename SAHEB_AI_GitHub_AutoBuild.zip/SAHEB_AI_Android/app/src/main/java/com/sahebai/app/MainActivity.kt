package com.sahebai.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*
import java.util.Locale
import kotlin.math.*

private data class Landmark(val name:String,val lat:Double,val lng:Double,val story:String)

class MainActivity : ComponentActivity() {
    private val landmarks = listOf(
        Landmark("جدة التاريخية – البلد",21.4858,39.1862,"أنت الآن في جدة التاريخية، إحدى أبرز المناطق التراثية في جدة. من هنا تبدأ جولتك مع صاحب."),
        Landmark("بيت نصيف",21.4867,39.1867,"بيت نصيف من أشهر البيوت التاريخية في جدة، ويرتبط بتاريخ اجتماعي وتجاري مهم للمدينة."),
        Landmark("سوق العلوي",21.4845,39.1869,"سوق العلوي من الأسواق التاريخية في قلب جدة القديمة، وكان جزءًا من الحركة التجارية للبلد."),
        Landmark("باب مكة",21.4910,39.1881,"باب مكة أحد الأبواب التاريخية المرتبطة بسور جدة القديم، وكان مدخلًا مهمًا للمدينة.")
    )
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); requestPermissions(); setContent { SahebApp() } }
    private fun requestPermissions(){ val p=mutableListOf<String>(); if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.ACCESS_FINE_LOCATION); if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.RECORD_AUDIO); if(p.isNotEmpty())registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){}.launch(p.toTypedArray()) }
    @Composable fun SahebApp(){
        var pos by remember { mutableStateOf(LatLng(21.4858,39.1862)) }
        var active by remember { mutableStateOf(false) }; var message by remember { mutableStateOf("هلا، أنا صاحب. شغّل الجولة وأنا أتكلم معك عندما تقترب من المعالم.") }
        val tts=remember { TextToSpeech(this){ } }; DisposableEffect(Unit){ onDispose{tts.shutdown()} }
        LaunchedEffect(Unit){ val client=LocationServices.getFusedLocationProviderClient(this@MainActivity); if(ContextCompat.checkSelfPermission(this@MainActivity,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED){ client.lastLocation.addOnSuccessListener{it?.let{pos=LatLng(it.latitude,it.longitude)}} } }
        MaterialTheme(colorScheme=darkColorScheme(primary=androidx.compose.ui.graphics.Color(0xFFD6B56A),background=androidx.compose.ui.graphics.Color(0xFF10231D))){
            Column(Modifier.fillMaxSize()){
                Row(Modifier.fillMaxWidth().padding(18.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){ Text("SAHEB AI",style=MaterialTheme.typography.headlineSmall); Text(if(active)"● الجولة تعمل" else "جاهز") }
                Box(Modifier.fillMaxWidth().weight(1f)){ GoogleMap(modifier=Modifier.fillMaxSize(),cameraPositionState=rememberCameraPositionState{position=CameraPosition.fromLatLngZoom(pos,15f)},properties=MapProperties(isMyLocationEnabled=ContextCompat.checkSelfPermission(this@MainActivity,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED),uiSettings=MapUiSettings(myLocationButtonEnabled=true)){ landmarks.forEach{Marker(state=MarkerState(LatLng(it.lat,it.lng)),title=it.name)} } }
                Card(Modifier.fillMaxWidth().padding(14.dp)){ Column(Modifier.padding(16.dp)){ Text("صاحب",style=MaterialTheme.typography.titleLarge); Spacer(Modifier.height(8.dp)); Text(message); Spacer(Modifier.height(12.dp)); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ Button(onClick={active=!active; if(active){message="بدأت الجولة. تحرك بحرية، وسأعرّفك على الأماكن القريبة.";tts.speak(message,TextToSpeech.QUEUE_FLUSH,null,"saheb",null)} }){Text(if(active)"إيقاف الجولة" else "ابدأ الجولة")}; OutlinedButton(onClick={tts.speak(message,TextToSpeech.QUEUE_FLUSH,null,"saheb",null)}){Text("اسمع")}} } }
            }
        }
    }
}
