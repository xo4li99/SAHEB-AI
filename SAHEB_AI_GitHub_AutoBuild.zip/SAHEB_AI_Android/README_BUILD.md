# SAHEB AI — Build the APK

This repository is configured to build an Android APK automatically with GitHub Actions.

## What you need
1. A GitHub account.
2. Upload this project as a repository.
3. Optional: add a GitHub Actions secret named `MAPS_API_KEY` containing a Google Maps Android API key. The APK will still build without it, but Google Maps will not display correctly.

## Build
After pushing to the `main` branch, open **Actions → Build SAHEB AI APK**. When the workflow finishes, download the artifact named **SAHEB-AI-debug-apk** and extract `app-debug.apk`.

You can also run it manually from **Actions → Build SAHEB AI APK → Run workflow**.

The generated APK is a debug build intended for personal testing. A signed release APK for Google Play requires a release keystore and Play Console configuration.
