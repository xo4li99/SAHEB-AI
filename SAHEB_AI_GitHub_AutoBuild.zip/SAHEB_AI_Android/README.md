# SAHEB AI — Android v1.0

This is the native Android project and backend foundation for SAHEB AI.

## Build
1. Open the folder in Android Studio.
2. Add a Google Maps Android API key to the Gradle property `MAPS_API_KEY` (or replace the manifest placeholder).
3. Sync Gradle and Build > Generate App Bundle/APK.

## AI backend
`backend/` is a Node.js service. Copy `.env.example` to `.env`, set `OPENAI_API_KEY`, run `npm install`, then `npm start`.

Do not put an OpenAI API key inside the Android APK.

## Current MVP
- Native Android / Jetpack Compose
- GPS permission + current location
- Google Map
- Landmark markers
- Arabic text-to-speech
- Tour start/stop
- Backend `/ask` endpoint for AI

Production additions still required before public launch: persistent landmark database, verified source ingestion, robust background geofencing, auth, analytics, rate limiting, backend deployment, and store signing.
